package com.aura.camera

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

private data class Look(val name: String, val brightness: Float, val contrast: Float, val saturation: Float, val warmth: Float = 0f)

private val looks = listOf(
    Look("Natural", 1f, 1f, 1f),
    Look("iPhone", 1.04f, 1.08f, 1.08f, 2f),
    Look("DSLR", 1.02f, 1.16f, 1.12f, 1f),
    Look("Cinematic", 0.96f, 1.2f, 0.88f, -3f),
    Look("Vintage", 1.04f, 0.92f, 0.78f, 8f),
    Look("Moody", 0.88f, 1.24f, 0.9f, -5f),
    Look("Vivid", 1.04f, 1.12f, 1.32f, 1f)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AuraApp() }
    }
}

@Composable
fun AuraApp() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var photo by remember { mutableStateOf<Bitmap?>(null) }
    var capture by remember { mutableStateOf<ImageCapture?>(null) }
    var selectedLook by remember { mutableStateOf(looks[0]) }
    var brightness by remember { mutableFloatStateOf(1f) }
    var contrast by remember { mutableFloatStateOf(1f) }
    var saturation by remember { mutableFloatStateOf(1f) }
    var command by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Ready — take a photo or import one") }
    var cameraMode by remember { mutableStateOf(true) }
    var showAdjust by remember { mutableStateOf(false) }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            context.contentResolver.openInputStream(it)?.use { stream ->
                photo = BitmapFactory.decodeStream(stream)
                status = "Photo imported. Choose a look or use AI command."
                cameraMode = false
            }
        }
    }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        status = if (granted) "Camera permission granted" else "Camera permission denied"
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    val edited = remember(photo, selectedLook, brightness, contrast, saturation) {
        photo?.let { applyLook(it, selectedLook, brightness, contrast, saturation) }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = ComposeColor(0xFF8CE8D0),
        background = ComposeColor(0xFF090D12),
        surface = ComposeColor(0xFF151C24)
    )) {
        Column(
            Modifier.fillMaxSize().background(ComposeColor(0xFF090D12)).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("AURA", color = ComposeColor.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineMedium)
                    Text("AI SMART CAMERA", color = ComposeColor(0xFF8CE8D0), style = MaterialTheme.typography.labelMedium)
                }
                Text("BETA 1.0", color = ComposeColor.LightGray, style = MaterialTheme.typography.labelSmall)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = cameraMode, onClick = { cameraMode = true }, label = { Text("Camera") })
                FilterChip(selected = !cameraMode, onClick = { cameraMode = false; if (photo == null) gallery.launch("image/*") }, label = { Text("Editor") })
                OutlinedButton(onClick = { gallery.launch("image/*") }) { Icon(Icons.Default.PhotoLibrary, null); Spacer(Modifier.width(5.dp)); Text("Gallery") }
            }
            Spacer(Modifier.height(10.dp))

            if (cameraMode && photo == null) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            val previewView = PreviewView(ctx)
                            val providerFuture = ProcessCameraProvider.getInstance(ctx)
                            providerFuture.addListener({
                                val provider = providerFuture.get()
                                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                                val imageCapture = ImageCapture.Builder()
                                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                                    .build()
                                capture = imageCapture
                                try {
                                    provider.unbindAll()
                                    provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                                } catch (_: Exception) { status = "Could not start camera" }
                            }, ContextCompat.getMainExecutor(ctx))
                            previewView
                        }
                    )
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        val cap = capture
                        if (cap == null) { status = "Camera is starting…"; return@Button }
                        val file = File(context.cacheDir, "aura_${System.currentTimeMillis()}.jpg")
                        val options = ImageCapture.OutputFileOptions.Builder(file).build()
                        cap.takePicture(options, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
                            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                                photo = BitmapFactory.decodeFile(file.absolutePath)
                                selectedLook = looks[0]
                                brightness = 1f; contrast = 1f; saturation = 1f
                                cameraMode = false
                                status = "Captured! Apply a look or AI command."
                            }
                            override fun onError(exception: ImageCaptureException) { status = "Capture failed: ${exception.message}" }
                        })
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ComposeColor(0xFF8CE8D0), contentColor = ComposeColor(0xFF07110F))
                ) { Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(8.dp)); Text("CAPTURE PHOTO", fontWeight = FontWeight.Bold) }
            } else {
                Box(Modifier.weight(1f).fillMaxWidth().background(ComposeColor(0xFF151C24), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                    if (edited != null) {
                        Image(bitmap = edited.asImageBitmap(), contentDescription = "Edited photo", modifier = Modifier.fillMaxSize())
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AddPhotoAlternate, null, tint = ComposeColor.LightGray, modifier = Modifier.size(48.dp))
                            Text("Import a photo to start editing", color = ComposeColor.LightGray)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(status, color = ComposeColor(0xFF8CE8D0), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                Text("AI LOOKS", color = ComposeColor.White, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    looks.forEach { look ->
                        FilterChip(selected = selectedLook.name == look.name, onClick = {
                            selectedLook = look; brightness = 1f; contrast = 1f; saturation = 1f
                            status = "${look.name} look applied"
                        }, label = { Text(look.name) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = command, onValueChange = { command = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Try: make it cinematic / iPhone look / DSLR portrait") },
                    label = { Text("AI COMMAND") },
                    trailingIcon = { IconButton(onClick = {
                        val c = command.lowercase()
                        val match = when {
                            "iphone" in c || "natural" in c -> looks[1]
                            "dslr" in c || "portrait" in c -> looks[2]
                            "cinema" in c || "movie" in c -> looks[3]
                            "vintage" in c || "film" in c -> looks[4]
                            "moody" in c || "dark" in c -> looks[5]
                            "vivid" in c || "bright" in c -> looks[6]
                            "auto" in c || "enhance" in c || "professional" in c -> looks[2]
                            else -> null
                        }
                        if (match != null) {
                            selectedLook = match; brightness = 1f; contrast = 1f; saturation = 1f
                            status = "Command applied: ${match.name} look"
                        } else status = "Try: iPhone, DSLR, cinematic, vintage, moody or vivid"
                    }) { Icon(Icons.Default.AutoFixHigh, contentDescription = "Apply command", tint = ComposeColor(0xFF8CE8D0)) } }
                )
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("MANUAL ADJUST", color = ComposeColor.White, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { showAdjust = !showAdjust }) { Text(if (showAdjust) "Hide" else "Adjust") }
                }
                if (showAdjust) {
                    SliderLine("Brightness", brightness, 0.5f, 1.5f) { brightness = it }
                    SliderLine("Contrast", contrast, 0.5f, 1.8f) { contrast = it }
                    SliderLine("Saturation", saturation, 0f, 2f) { saturation = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { photo = null; cameraMode = true; status = "Ready for next photo" }, modifier = Modifier.weight(1f)) { Text("New Photo") }
                    Button(onClick = {
                        val bmp = edited
                        if (bmp != null) {
                            val values = ContentValues().apply {
                                put(MediaStore.Images.Media.DISPLAY_NAME, "AURA_${System.currentTimeMillis()}.jpg")
                                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AuraCamera")
                            }
                            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                            if (uri != null) context.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 96, it) }
                            status = "Saved to Pictures/AuraCamera"
                        }
                    }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = ComposeColor(0xFF8CE8D0), contentColor = ComposeColor(0xFF07110F))) {
                        Icon(Icons.Default.Save, null); Text(" Save")
                    }
                }
            }
        }
    }
}

@Composable
private fun SliderLine(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = ComposeColor.White, style = MaterialTheme.typography.bodySmall)
            Text(String.format("%.2f", value), color = ComposeColor(0xFF8CE8D0), style = MaterialTheme.typography.bodySmall)
        }
        Slider(value = value, onValueChange = onChange, valueRange = min..max)
    }
}

private fun applyLook(src: Bitmap, look: Look, extraB: Float, extraC: Float, extraS: Float): Bitmap {
    val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(out)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    val sat = ColorMatrix().apply { setSaturation(look.saturation * extraS) }
    val c = look.contrast * extraC
    val b = (look.brightness * extraB - 1f) * 255f
    val contrastMatrix = ColorMatrix(floatArrayOf(
        c,0f,0f,0f,b, 0f,c,0f,0f,b, 0f,0f,c,0f,b, 0f,0f,0f,1f,0f
    ))
    sat.postConcat(contrastMatrix)
    paint.colorFilter = ColorMatrixColorFilter(sat)
    canvas.drawBitmap(src, 0f, 0f, paint)
    return out
}
