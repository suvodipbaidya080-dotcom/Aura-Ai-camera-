# AURA AI CAMERA — Android starter project

A native Android Studio starter app with:
- CameraX live preview and photo capture
- Gallery image import
- Local image looks: Natural, iPhone-inspired, DSLR-inspired, Cinematic, Vintage, Moody, Vivid
- Brightness, contrast and saturation sliders
- Simple command-to-look mapping
- JPEG export to Pictures/AuraCamera

## Important limitations of this first beta
The command box is a local keyword-based assistant, not a cloud generative-AI model. It applies bundled image adjustments. It does not create true optical iPhone/DSLR rendering, computational portrait depth, or AI object/background edits. Those require additional models and/or a secure AI service.
The app currently applies looks to imported/captured images after capture; live preview filters and video recording are not included yet.

## Build an APK
1. Install Android Studio (Giraffe or newer) on a computer.
2. Open this folder as a project.
3. Let Gradle sync and download dependencies.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be under `app/build/outputs/apk/debug/`.

Package: `com.aura.camera`
Minimum Android: 8.0 (API 26)
Target SDK: 35
